package itech2306Package1;

public class Animal 
{
	String name;
	String breed;
	String age;
	Animal pet;

	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setBreed(String breed)
	{
		this.breed=breed;
	}
	
	public String getAge()
	{
		return age;
	}
	
	public void setAge(String age)
	{
		this.age=age;
	}
	
	public String getBreed()
	{
		return breed;
	}
}
