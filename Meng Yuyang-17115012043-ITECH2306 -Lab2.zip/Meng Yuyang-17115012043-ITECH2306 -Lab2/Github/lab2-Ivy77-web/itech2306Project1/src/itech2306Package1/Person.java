package itech2306Package1;
public class Person 
{
	String name;
	String address;
	Animal  pet ;
	String postcode;
	
	public String getName() 
	{
		return name;
	}
	
	public void setName(String name) 
	{
		this.name = name;
	}
	
	public String getAddress() 
	{
		return address;
	}
	
	
	public void setAddress(String address) 
	{
		this.address = address;
	}
	
	public String getPostcode() 
	{
		return postcode;
	}
	
	
	public void setPostcode(String postcode) 
	{
		this.postcode = postcode;
	}
	
	Person (String _address, String _name, String _postcode)  
	{ 
		this.setAddress(_address); 
		this.setName (_name); 
		this.setPostcode (_postcode); 
	}

	public Person() 
	{
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) 
	{
		Person p = new Person();
		Animal myPet=new Animal();
		p.addAPet(myPet);
		System.out.println("the person is "+p);
	}
	
	void addAPet(Animal _pet) 
	{  
		this.pet = _pet; 
	}
}
	
	



	
