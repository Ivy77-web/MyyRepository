package homework;
public class A 
{
	public static void main(String[] args) 
	{
		double randomNumber = Math.random();
		randomNumber*=10;
		randomNumber++;
		int a= (int)randomNumber;
	
		if(a%2==0)
			System.out.println("The random number is even.");
		else
			System.out.println("The random number is odd.");
	}
}
